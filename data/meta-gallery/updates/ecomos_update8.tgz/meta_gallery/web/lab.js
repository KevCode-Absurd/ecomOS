'use strict';
// Creative lab: "Why it worked" breakdowns and image variants for image ads.
// Shared page: the breakdown runs on Claude through the page's `sample` capability (viewer's own Claude).
// Local app: both run on the local server, which keeps API keys in .env (never in this file).
let BREAKDOWNS = {};
const LABST = { status: null, sample: undefined, busy: {}, variants: {}, loaded: false };

async function labBoot() {
  if (LABST.loaded) return;
  LABST.loaded = true;
  try { const r = await fetch('breakdowns.json'); if (r.ok) { const d = await r.json(); if (d && typeof d === 'object') BREAKDOWNS = d; } } catch (e) { /* none yet */ }
  if (IS_CLAUDE) {
    try { LABST.sample = await window.claude.use('sample'); } catch (e) { LABST.sample = null; }
  } else {
    try { const r = await fetch('/api/ai-status'); LABST.status = r.ok ? await r.json() : null; } catch (e) { LABST.status = null; }
  }
}

// The facts both back ends see. Keep the wording of the prompt in sync with meta_gallery/ai.py.
function adFacts(id) {
  const ad = ENGINE.adDetail(id, state.since, state.until, { roas: VIEW.targets.roas, cpa: VIEW.targets.cpa });
  const m = ad.detail.metrics, t = VIEW.totals, c = ad.creative, r2x = (v) => (v === null || v === undefined ? null : Math.round(v * 100) / 100);
  const lc = ENGINE.lifecycle(id, (VIEW.targets.cpa || 5000) / 2);
  let domain = null;
  try { domain = c.link_url ? new URL(c.link_url).hostname : null; } catch (e) { domain = null; }
  return {
    ad_name: ad.name, campaign: ad.campaign_name, format: c.type_label, headline: c.headline || null,
    primary_text: (c.primary_text || '').slice(0, 1200) || null, call_to_action: c.cta || null, landing_domain: domain,
    tags: ad.tags ? { angle: ad.tags.angle.label, product: ad.tags.product.label, opening_line: ad.tags.hook.label } : null,
    dates: `${VIEW.range.since} to ${VIEW.range.until}`,
    this_ad: { spend_inr: r2x(m.spend), purchases: m.purchases, purchase_value_inr: r2x(m.purchase_value), roas: r2x(m.roas), cpa_inr: r2x(m.cpa), link_ctr_pct: r2x(m.link_ctr), impressions: m.impressions, days_with_spend: m.days_active, rank_by_spend: VIEW.ads[id] ? VIEW.ads[id].view.rank_by_spend : null },
    account_average: { roas: r2x(t.roas), cpa_inr: r2x(t.cpa), link_ctr_pct: r2x(t.link_ctr), ads: t.ads },
    verdict: ad.detail.verdict ? ad.detail.verdict.label : null, fatigue: ad.detail.fatigue ? ad.detail.fatigue.label : null,
    lifetime: lc ? { spend_inr: r2x(lc.lifetime.spend), roas: r2x(lc.lifetime.roas), first_day: lc.first_day, last_day: lc.last_day } : null,
  };
}
const BREAKDOWN_SHAPE = `{
  "verdict": "worked" | "mixed" | "did_not_work",
  "summary": "one sentence, plain words",
  "why": [{"point": "short reason", "evidence": "what in the image, copy or numbers shows it"}],
  "structure": {"hook": "", "layout": "", "product": "", "text_on_image": "", "offer": "", "proof": "", "cta": "", "look": ""},
  "keep": ["element to keep in new versions"],
  "test_next": ["one idea per line for a new version"],
  "watch_out": ["risk or weak spot"]
}`;
function breakdownPrompt(facts) {
  return 'You are a senior performance creative strategist for Meta ads. Study this image ad from Gehna, '
    + 'an Indian fine jewellery brand, and explain why it performed the way it did.\n\n'
    + `Ad data (JSON):\n${JSON.stringify(facts)}\n\n`
    + 'Rules:\n- Use the image, the copy and the numbers. Compare the ad\'s ROAS, CPA and link CTR with the account '
    + 'averages given. If the numbers are weak, say so honestly and set verdict accordingly.\n'
    + '- Plain, short sentences. No jargon. Use digits. No em dashes.\n'
    + '- 3 to 5 items in why. 3 to 6 items in keep and test_next. 1 to 3 in watch_out.\n'
    + '- structure: describe what is actually in the image. Use "none" when a part is missing.\n\n'
    + `Reply with only this JSON:\n${BREAKDOWN_SHAPE}`;
}
function cleanBd(d) {
  const s = (v, n) => String(v ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, n);
  const list = (v, n, m) => (Array.isArray(v) ? v : []).slice(0, n).map((x) => s(x, m)).filter(Boolean);
  const st = d && typeof d.structure === 'object' && d.structure ? d.structure : {};
  return {
    verdict: ['worked', 'mixed', 'did_not_work'].includes(d.verdict) ? d.verdict : 'mixed',
    summary: s(d.summary, 400),
    why: (Array.isArray(d.why) ? d.why : []).slice(0, 6).map((w) => (typeof w === 'string' ? { point: s(w, 200), evidence: '' } : { point: s(w && w.point, 200), evidence: s(w && w.evidence, 400) })).filter((w) => w.point),
    structure: Object.fromEntries(['hook', 'layout', 'product', 'text_on_image', 'offer', 'proof', 'cta', 'look'].map((k) => [k, s(st[k], 300)])),
    keep: list(d.keep, 8, 200), test_next: list(d.test_next, 8, 240), watch_out: list(d.watch_out, 4, 240),
    model: s(d.model, 60), provider: s(d.provider, 20), date: s(d.date, 20),
  };
}
function thumbBlob(id) {
  const src = thumbSrc(id);
  if (!src || !src.startsWith('data:')) return null;
  const [head, b64] = src.split(',');
  const bin = atob(b64), arr = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
  return new Blob([arr], { type: head.slice(5, head.indexOf(';')) || 'image/jpeg' });
}

// ---------- rendering ----------
const STRUCT_LABELS = { hook: 'Hook', layout: 'Layout', product: 'Product', text_on_image: 'Text on image', offer: 'Offer', proof: 'Proof', cta: 'Call to action', look: 'Look and feel' };
const VERDICT_TXT = { worked: ['Worked', 'v-scale'], mixed: ['Mixed', 'v-watch'], did_not_work: ['Did not work', 'v-cut'] };
function bdHtml(b) {
  const [vt, vc] = VERDICT_TXT[b.verdict] || VERDICT_TXT.mixed;
  const li = (xs) => xs.map((x) => `<li>${esc(x)}</li>`).join('');
  return `<div class="bd">
    <div class="bd-top"><span class="chip ${vc}">${vt}</span>${b.date ? `<span class="small muted">Updated ${esc(dateLabel(b.date))}</span>` : ''}</div>
    ${b.summary ? `<p class="bd-sum">${esc(b.summary)}</p>` : ''}
    ${b.why.length ? `<h3>Why it performed this way</h3><ul class="bd-why">${b.why.map((w) => `<li><strong>${esc(w.point)}</strong>${w.evidence ? `<span>${esc(w.evidence)}</span>` : ''}</li>`).join('')}</ul>` : ''}
    <h3>Structure of the ad</h3>
    <div class="bd-grid">${Object.entries(STRUCT_LABELS).filter(([k]) => b.structure[k] && b.structure[k].toLowerCase() !== 'none').map(([k, l]) => `<div><span>${l}</span><p>${esc(b.structure[k])}</p></div>`).join('')}</div>
    ${b.keep.length ? `<h3>Keep in new versions</h3><div class="bd-keep">${b.keep.map((k) => `<span>${esc(k)}</span>`).join('')}</div>` : ''}
    ${b.test_next.length ? `<h3>Ideas to test next</h3><ul class="bd-list">${li(b.test_next)}</ul>` : ''}
    ${b.watch_out.length ? `<h3>Watch out</h3><ul class="bd-list warn">${li(b.watch_out)}</ul>` : ''}
    <p class="small muted">An AI reading of the ad and its numbers. Check it before acting on it.</p>
  </div>`;
}
function variantsHtml(id) {
  const list = LABST.variants[id] || [];
  if (!list.length) return '';
  return `<div class="vgrid">${list.map((v) => v.error ? `<div class="vcard err"><strong>${esc(v.label)}</strong><span class="small">${esc(v.error)}</span></div>`
    : `<figure class="vcard"><a href="/variants/${esc(id)}/${esc(v.file)}" target="_blank" rel="noopener"><img src="/variants/${esc(id)}/${esc(v.file)}" alt="${esc(v.label)}" loading="lazy"></a><figcaption><span class="vtag ${v.closeness === 'close' ? 'close' : ''}">${v.closeness === 'close' ? 'Close to original' : 'New idea'}</span><strong>${esc(v.label)}</strong>${v.principle ? `<span class="small">${esc(v.principle)}</span>` : ''}<span class="small muted">${esc(v.date || '')}</span><a class="btn ghost small-btn" href="/variants/${esc(id)}/${esc(v.file)}" download="Gehna-${esc(id)}-${esc(v.file)}">Download</a></figcaption></figure>`).join('')}</div>`;
}
window.labSection = function labSection(id) {
  return `<section id="lab" class="lab" data-id="${esc(id)}"><div class="lab-head"><h3 style="margin:0">Creative lab</h3><span class="small muted">Image ads only</span></div><div id="labBody"><p class="small muted">Loading…</p></div></section>`;
};
function labRender(id) {
  const box = $('labBody');
  if (!box || $('lab').dataset.id !== id) return;
  const b = BREAKDOWNS[id] ? cleanBd(BREAKDOWNS[id]) : null;
  const busy = LABST.busy[id];
  let canBd = false, note = '';
  if (IS_CLAUDE) {
    canBd = !!LABST.sample;
    note = canBd ? 'Takes about 30 to 60 seconds.' : 'Sign in to Claude to see why this ad worked.';
  } else if (LABST.status) {
    canBd = LABST.status.breakdown;
    note = canBd ? 'Takes about 30 to 60 seconds.' : 'AI is not set up on this computer yet.';
  } else note = 'AI is not available right now.';
  const canVar = !IS_CLAUDE && LABST.status && LABST.status.variants;
  const varCtl = canVar ? `<div class="lab-ctl">
      <label class="field">How many <select id="labN"><option value="2">2</option><option value="3" selected>3</option><option value="4">4</option><option value="5">5</option></select></label>
      <label class="field">Size <select id="labSize"><option value="square">Square 1:1</option><option value="portrait">Portrait 4:5</option><option value="story">Story 9:16</option></select></label>
      <label class="field">Quality <select id="labQ"><option value="medium" selected>Medium</option><option value="high">High</option><option value="low">Low (cheapest)</option></select></label>
      <button class="btn" type="button" data-lab="variants"${busy ? ' disabled' : ''}>${busy === 'variants' ? 'Making images…' : 'Make image variants'}</button></div>
      <p class="small muted">Version 1 stays close to this ad. The rest are new ideas built on why it worked, each testing a different reason. About 1 to 2 minutes in total.</p>`
    : IS_CLAUDE ? '<p class="small muted">New image versions are made from the desktop version of this gallery.</p>' : '';
  box.innerHTML = `${b ? bdHtml(b) : '<p class="lab-lead">Get a breakdown of why this ad worked and how it is built.</p>'}
    <div class="lab-actions"><button class="btn${b ? ' ghost' : ''}" type="button" data-lab="breakdown"${!canBd || busy ? ' disabled' : ''}>${busy === 'breakdown' ? 'Reading the ad…' : b ? 'Run again' : 'Why it worked'}</button>${busy ? '<span class="lab-spin" aria-hidden="true"></span>' : ''}</div>
    <p class="small muted" id="labMsg">${note}</p>
    ${b ? `<div class="lab-var"><h3>New versions of this ad</h3>${varCtl}<div id="labVariants">${variantsHtml(id)}</div></div>` : ''}`;
}
async function labRunBreakdown(id) {
  LABST.busy[id] = 'breakdown'; labRender(id);
  const facts = adFacts(id);
  let msg = '';
  try {
    let out;
    if (IS_CLAUDE) {
      const caps = await LABST.sample.limits().catch(() => null);
      const img = caps && caps.images ? thumbBlob(id) : null;
      const raw = await LABST.sample.json(breakdownPrompt(facts), { modelTier: 'default', cache: false, ...(img ? { images: img } : {}) });
      out = { ...cleanBd(raw), provider: 'claude', model: 'Claude', date: new Date().toISOString().slice(0, 10) };
      BREAKDOWNS = { ...BREAKDOWNS, [id]: out };
      const r = await saveFile('breakdowns.json', BREAKDOWNS);
      msg = r === 'saved' ? 'Saved for the team.' : r === 'local-only' ? 'Shown for you only. Saving for the team is off for you.' : r;
    } else {
      const r = await fetch('/api/breakdown', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ad_id: id, facts }) });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) throw { code: 'server', message: j.error || 'The breakdown failed.' };
      out = j;
      BREAKDOWNS = { ...BREAKDOWNS, [id]: out };
      msg = 'Saved.';
      loadVariants(id);
    }
  } catch (e) {
    const copy = { not_granted: 'Claude is not allowed for this page. Allow it when asked, or reload.', rate_limited: 'Too many requests just now. Wait a minute and try again.', invalid_json: 'The answer came back in the wrong shape. Try again.', refused: 'Claude declined this one.', session_expired: 'Sign in to Claude again.', cancelled: '' };
    msg = e && e.code in copy ? copy[e.code] : (e && e.message) || 'Something went wrong. Try again.';
  }
  delete LABST.busy[id];
  labRender(id);
  if ($('labMsg') && msg) $('labMsg').textContent = msg;
}
async function loadVariants(id) {
  if (IS_CLAUDE) return;
  try { const r = await fetch('/api/variants/' + encodeURIComponent(id)); if (r.ok) LABST.variants[id] = await r.json(); } catch (e) { /* none */ }
  if ($('labVariants')) $('labVariants').innerHTML = variantsHtml(id);
}
async function labRunVariants(id) {
  const n = $('labN').value, size = $('labSize').value, quality = $('labQ').value;
  LABST.busy[id] = 'variants'; labRender(id);
  if ($('labMsg')) $('labMsg').textContent = `Planning ${n} ideas, then making the images. About 1 to 2 minutes. You can keep browsing.`;
  let msg = '';
  try {
    const r = await fetch('/api/variants', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ad_id: id, n: Number(n), size, quality }) });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.error || 'Could not make images.');
    LABST.variants[id] = j.all;
    const bad = j.made.filter((m) => m.error);
    msg = bad.length ? `${j.made.length - bad.length} of ${j.made.length} made. ${bad[0].error}` : `${j.made.length} images made. Download the ones you like and launch them in Ads Manager.`;
  } catch (e) { msg = e.message; }
  delete LABST.busy[id];
  labRender(id);
  if ($('labMsg')) $('labMsg').textContent = msg;
}
window.initLab = async function initLab(id) {
  await labBoot();
  labRender(id);
  loadVariants(id);
};
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-lab]');
  if (!b || !$('lab')) return;
  const id = $('lab').dataset.id;
  if (b.dataset.lab === 'breakdown') labRunBreakdown(id);
  if (b.dataset.lab === 'variants') labRunVariants(id);
});
