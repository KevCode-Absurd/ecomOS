"""Local read-only gallery server.

Serves views computed from the cached snapshot and cached creative images on
127.0.0.1. It never reads credentials and never calls the Meta API. Images are
downloaded once from the CDN URL stored in the snapshot and then served from disk.

"/" serves the same web page as the shared claude.ai page (meta_gallery/web).
The old page stays at /old.

The only writes it accepts are team settings (targets, exclusion presets,
report branding) and team notes on ads, each saved to a local file after
validation. Every other write is rejected.
"""
import argparse
import json
import mimetypes
import re
import threading
import time
import urllib.request
from collections import OrderedDict
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from . import ai
from . import settings as settings_mod
from .snapshot import DATA
from .view import Engine, ViewError

STATIC = Path(__file__).resolve().parent / 'static'
WEB = Path(__file__).resolve().parent / 'web'
WEB_FILES = ('engine.js', 'app.js', 'insights.js', 'overview.js', 'lab.js')
COMPETITORS = DATA / 'competitors.json'
CACHE = DATA / 'cache' / 'gallery.json'
IMAGES = DATA / 'images'
SAFE_ID = re.compile(r'^[0-9]{5,25}$')
MAX_BODY = 32_000
MAX_NOTES_BODY = 2_000_000
MAX_AI_BODY = 64_000


class Gallery:
    def __init__(self, path=CACHE, settings_path=None, notes_path=None):
        self.path = Path(path)
        self.settings_path = settings_path
        self.notes_path = notes_path
        self._page = None
        self._mtime = None
        self._data = None
        self._engine = None
        self._views = OrderedDict()
        self._lock = threading.Lock()

    @property
    def data(self):
        mtime = self.path.stat().st_mtime
        if mtime != self._mtime:
            with self._lock:
                self._data = json.loads(self.path.read_text(encoding='utf-8'))
                self._engine = Engine(self._data)
                self._views.clear()
                self._page = None
                self._mtime = mtime
        return self._data

    def page_json(self):
        """data.json for the web page: the cache without Meta CDN links."""
        from .share import page_data
        self.data
        with self._lock:
            if self._page is None:
                self._page = json.dumps(page_data(self._data), ensure_ascii=False, separators=(',', ':')).encode('utf-8')
            return self._page

    def notes(self):
        return settings_mod.load_notes(self.notes_path)

    def save_notes(self, body):
        return settings_mod.save_notes(body, self.notes_path)

    @property
    def engine(self):
        self.data
        return self._engine

    def settings(self):
        return settings_mod.load(self.settings_path)

    def save_settings(self, body):
        out = settings_mod.save(body, self.settings_path)
        with self._lock:
            self._views.clear()
        return out

    def meta(self):
        e = self.engine
        return {'meta': self.data['meta'], 'campaigns': e.campaigns(), 'settings': self.settings()}

    def view(self, since, until, keywords, campaign_ids):
        targets = self.settings()['targets']
        e = self.engine
        key = (since, until, tuple(keywords), tuple(sorted(campaign_ids)), targets['roas'], targets['cpa'], self._mtime)
        with self._lock:
            if key in self._views:
                self._views.move_to_end(key)
                return self._views[key]
        v = e.view(since, until, keywords, campaign_ids, targets)
        with self._lock:
            self._views[key] = v
            while len(self._views) > 32:
                self._views.popitem(last=False)
        return v

    def ad(self, ad_id):
        return self.data['ads'].get(ad_id)

    def ad_detail(self, ad_id, since, until, keywords, campaign_ids):
        return self.engine.ad_detail(ad_id, since, until, self.settings()['targets'], keywords, campaign_ids)


def image_path(creative):
    key = creative.get('image_hash') or f"creative_{creative.get('id')}"
    return IMAGES / f'{key}.jpg'


def cache_image(creative, timeout=10):
    """Download the creative's display image once. Returns the local path or None."""
    url = creative.get('display_image_url') or creative.get('image_url') or creative.get('thumbnail_url')
    return download(url, image_path(creative), timeout)


def cache_card(card, timeout=10):
    """Download one carousel card image once."""
    if not card.get('image_hash'):
        return None
    return download(card.get('image_url'), IMAGES / f"{card['image_hash']}.jpg", timeout)


_FAILED = {}           # path -> time of last failed download
RETRY_AFTER = 600      # seconds before a failed image is tried again


def download(url, path, timeout=10):
    if path.exists() and path.stat().st_size > 0:
        return path
    if not url or not url.startswith('https://'):
        return None
    # A failed image is not retried on every page load, so one bad link cannot hold the page up.
    if time.time() - _FAILED.get(str(path), 0) < RETRY_AFTER:
        return None
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'ecomOS-gallery/0.2'})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read()
    except Exception:
        body = None
    if not body:
        _FAILED[str(path)] = time.time()
        return None
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(body)
    return path


def image_bytes(ad):
    """The ad's cached image as (bytes, media type), downloading it once if needed."""
    path = cache_image(ad['creative']) if ad else None
    if not path:
        return None, None
    data = path.read_bytes()
    kind = 'image/png' if data[:8] == b'\x89PNG\r\n\x1a\n' else 'image/webp' if data[8:12] == b'WEBP' else 'image/jpeg'
    return data, kind


def query_filters(qs):
    since = (qs.get('since') or [None])[0]
    until = (qs.get('until') or [None])[0]
    kw = [k for part in qs.get('kw', []) for k in part.split(',')]
    camps = [c for part in qs.get('camp', []) for c in part.split(',') if SAFE_ID.match(c)]
    return since, until, kw, camps


def make_handler(gallery):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):
            pass

        def send_json(self, obj, status=200):
            body = json.dumps(obj, ensure_ascii=False).encode('utf-8')
            self.send_response(status)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def send_bytes(self, body, ctype, cache='no-cache'):
            self.send_response(200)
            self.send_header('Content-Type', ctype)
            self.send_header('Cache-Control', cache)
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def send_file(self, path, cache='no-cache'):
            body = path.read_bytes()
            self.send_response(200)
            self.send_header('Content-Type', mimetypes.guess_type(str(path))[0] or 'application/octet-stream')
            self.send_header('Cache-Control', cache)
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            url = urlparse(self.path)
            parts = [p for p in url.path.split('/') if p]
            qs = parse_qs(url.query)
            try:
                if not parts:
                    page = (WEB / 'index.html').read_text(encoding='utf-8')
                    doc = ('<!doctype html><html lang="en"><head><meta charset="utf-8">'
                           '<meta name="viewport" content="width=device-width, initial-scale=1"></head><body>'
                           + page + '</body></html>')
                    return self.send_bytes(doc.encode('utf-8'), 'text/html; charset=utf-8')
                if len(parts) == 1 and parts[0] in WEB_FILES:
                    return self.send_bytes((WEB / parts[0]).read_bytes(), 'text/javascript; charset=utf-8')
                if parts == ['data.json']:
                    return self.send_bytes(gallery.page_json(), 'application/json; charset=utf-8')
                if parts == ['thumbs.json']:
                    # No embedded previews locally; the page loads each image from /img/<ad id>.
                    return self.send_json({'error': 'not used locally'}, 404)
                if parts == ['settings.json']:
                    return self.send_json(gallery.settings())
                if parts == ['notes.json']:
                    return self.send_json(gallery.notes())
                if parts == ['competitors.json']:
                    if COMPETITORS.is_file():
                        return self.send_file(COMPETITORS)
                    return self.send_json({'error': 'not found'}, 404)
                if parts == ['breakdowns.json']:
                    return self.send_json(ai.load_breakdowns())
                if parts == ['api', 'ai-status']:
                    return self.send_json(ai.status())
                if len(parts) == 3 and parts[:2] == ['api', 'variants'] and SAFE_ID.match(parts[2]):
                    return self.send_json(ai.list_variants(parts[2]))
                if len(parts) == 3 and parts[0] == 'variants':
                    path = ai.variant_path(parts[1], parts[2])
                    if path:
                        return self.send_file(path, cache='max-age=86400')
                    return self.send_json({'error': 'not found'}, 404)
                if parts == ['old']:
                    return self.send_file(STATIC / 'index.html')
                if parts == ['report']:
                    return self.send_file(STATIC / 'report.html')
                if parts[0] == 'static' and len(parts) == 2 and re.match(r'^[\w.-]+$', parts[1]):
                    path = STATIC / parts[1]
                    return self.send_file(path) if path.is_file() else self.send_json({'error': 'not found'}, 404)
                if parts == ['api', 'meta']:
                    return self.send_json(gallery.meta())
                if parts == ['api', 'view']:
                    return self.send_json(gallery.view(*query_filters(qs)))
                if parts == ['api', 'settings']:
                    return self.send_json(gallery.settings())
                if len(parts) == 3 and parts[:2] == ['api', 'ad'] and SAFE_ID.match(parts[2]):
                    ad = gallery.ad_detail(parts[2], *query_filters(qs))
                    return self.send_json(ad) if ad else self.send_json({'error': 'not found'}, 404)
                if len(parts) == 2 and parts[0] == 'img' and SAFE_ID.match(parts[1]):
                    ad = gallery.ad(parts[1])
                    path = cache_image(ad['creative']) if ad else None
                    if path:
                        return self.send_file(path, cache='max-age=86400')
                    return self.send_json({'error': 'image unavailable'}, 404)
                if len(parts) == 3 and parts[0] == 'card' and SAFE_ID.match(parts[1]) and parts[2].isdigit():
                    ad = gallery.ad(parts[1])
                    cards = ad['creative'].get('cards') or [] if ad else []
                    idx = int(parts[2])
                    path = cache_card(cards[idx]) if idx < len(cards) else None
                    if path:
                        return self.send_file(path, cache='max-age=86400')
                    return self.send_json({'error': 'image unavailable'}, 404)
                return self.send_json({'error': 'not found'}, 404)
            except ViewError as e:
                return self.send_json({'error': str(e)}, 400)
            except FileNotFoundError:
                return self.send_json({'error': 'Gallery cache missing. Run: python -m meta_gallery.snapshot'}, 503)

        def do_POST(self):
            url = urlparse(self.path)
            savers = {'/api/settings': (gallery.save_settings, MAX_BODY),
                      '/api/save/settings.json': (gallery.save_settings, MAX_BODY),
                      '/api/save/notes.json': (gallery.save_notes, MAX_NOTES_BODY),
                      '/api/breakdown': (self.ai_breakdown, MAX_AI_BODY),
                      '/api/variants': (self.ai_variants, MAX_AI_BODY)}
            if url.path not in savers:
                return self.send_json({'error': 'read-only'}, 405)
            save, limit = savers[url.path]
            # Only same-origin JSON from the local page. This blocks other websites posting here.
            origin = self.headers.get('Origin')
            host = self.headers.get('Host', '')
            if host.split(':')[0] not in ('127.0.0.1', 'localhost') or (origin and origin != f'http://{host}'):
                return self.send_json({'error': 'forbidden origin'}, 403)
            if (self.headers.get('Content-Type') or '').split(';')[0].strip() != 'application/json':
                return self.send_json({'error': 'JSON only'}, 415)
            length = int(self.headers.get('Content-Length') or 0)
            if not 0 < length <= limit:
                return self.send_json({'error': 'body too large or empty'}, 413)
            try:
                body = json.loads(self.rfile.read(length).decode('utf-8'))
                return self.send_json(save(body))
            except ai.AIError as e:
                return self.send_json({'error': str(e)}, 502)
            except (ValueError, UnicodeDecodeError, TypeError) as e:
                return self.send_json({'error': str(e)}, 400)

        def ai_breakdown(self, body):
            """body: {ad_id, facts}. facts is the ad data the page shows (same as the shared page sends Claude)."""
            ad_id = str(body.get('ad_id') or '')
            ad = gallery.ad(ad_id) if SAFE_ID.match(ad_id) else None
            if not ad:
                raise ValueError('Unknown ad.')
            facts = body.get('facts') if isinstance(body.get('facts'), dict) else {}
            data, kind = image_bytes(ad)
            result = ai.breakdown(facts, data, kind or 'image/jpeg')
            return ai.save_breakdown(ad_id, result)

        def ai_variants(self, body):
            ad_id = str(body.get('ad_id') or '')
            ad = gallery.ad(ad_id) if SAFE_ID.match(ad_id) else None
            if not ad:
                raise ValueError('Unknown ad.')
            data, kind = image_bytes(ad)
            bd = ai.load_breakdowns().get(ad_id)
            facts = body.get('facts') if isinstance(body.get('facts'), dict) else {}
            facts.setdefault('headline', ad['creative'].get('headline') or '')
            facts.setdefault('primary_text', (ad['creative'].get('primary_text') or '')[:1200])
            made = ai.make_variants(ad_id, facts, data, bd, body.get('n', 3), body.get('size', 'square'), body.get('quality', 'medium'), media_type=kind or 'image/jpeg')
            return {'made': made, 'all': ai.list_variants(ad_id)}

        def reject(self):
            self.send_json({'error': 'read-only'}, 405)

        do_PUT = do_DELETE = do_PATCH = reject

    return Handler


def prefetch_images(gallery, workers=8):
    """Download every creative and carousel card image, 8 at a time."""
    jobs = {}
    for ad in gallery.data['ads'].values():
        c = ad['creative']
        jobs.setdefault(str(image_path(c)), (cache_image, c))
        for card in c.get('cards') or []:
            if card.get('image_hash'):
                jobs.setdefault(card['image_hash'], (cache_card, card))
    todo = list(jobs.values())
    ok = missing = 0
    with ThreadPoolExecutor(max_workers=workers) as pool:
        for i, result in enumerate(pool.map(lambda job: job[0](job[1]), todo), 1):
            if result:
                ok += 1
            else:
                missing += 1
            if i % 50 == 0 or i == len(todo):
                print(f'{i}/{len(todo)} checked', flush=True)
    print(f'Images cached: {ok}. Unavailable: {missing}.')
    return ok, missing


def main(argv=None):
    parser = argparse.ArgumentParser(description='Serve the local Meta ad gallery.')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--prefetch-images', action='store_true', help='Download all creative images, then exit.')
    args = parser.parse_args(argv)
    gallery = Gallery()
    if args.prefetch_images:
        prefetch_images(gallery)
        return
    server = ThreadingHTTPServer(('127.0.0.1', args.port), make_handler(gallery))
    print(f'Gallery running at http://127.0.0.1:{args.port}  (Ctrl+C to stop)')
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == '__main__':
    main()
