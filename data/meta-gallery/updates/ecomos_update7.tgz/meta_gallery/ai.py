"""Creative lab: explain why an image ad worked, then make new image ads like it.

Runs only on the local server, so API keys stay in .env on this machine and never
reach the browser. Nothing here touches the Meta ad account.

- Breakdown: Claude (ANTHROPIC_API_KEY) reads the ad image, copy and numbers and
  returns a JSON breakdown. Falls back to OpenAI (OPENAI_API_KEY) if there is no
  Anthropic key.
- Variants: OpenAI image edits (OPENAI_API_KEY) with the ad image as the reference.

Models can be changed in .env: AI_TEXT_MODEL, AI_OPENAI_TEXT_MODEL, AI_IMAGE_MODEL.
Results are saved under data/meta-gallery/ (breakdowns.json, variants/<ad id>/).
"""
import base64
import json
import re
import threading
import time
import urllib.error
import urllib.request
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from .graph_client import load_env
from .snapshot import DATA, ROOT

BREAKDOWNS = DATA / 'breakdowns.json'
VARIANTS = DATA / 'variants'
DEFAULTS = {
    'AI_TEXT_MODEL': 'claude-sonnet-5',
    'AI_OPENAI_TEXT_MODEL': 'gpt-6-luna',
    'AI_IMAGE_MODEL': 'gpt-image-2.5-sunburst',
    'AI_IMAGE_FALLBACK': 'gpt-image-2',
}
SIZES = {'square': '1024x1024', 'portrait': '1024x1280', 'story': '1024x1824'}
QUALITIES = ('low', 'medium', 'high')
SAFE_ID = re.compile(r'^[0-9]{5,25}$')
SAFE_FILE = re.compile(r'^[A-Za-z0-9_-]{1,80}\.(png|jpg|jpeg|webp)$')
_lock = threading.Lock()


class AIError(Exception):
    """A message that is safe to show in the page (never contains a key)."""


def settings(env_path=None):
    env = load_env(Path(env_path) if env_path else ROOT / '.env')
    cfg = {k: env.get(k) or v for k, v in DEFAULTS.items()}
    cfg['anthropic_key'] = env.get('ANTHROPIC_API_KEY') or ''
    cfg['openai_key'] = env.get('OPENAI_API_KEY') or ''
    return cfg


def status(env_path=None):
    """What the page may offer. Never includes keys."""
    cfg = settings(env_path)
    text = 'claude' if cfg['anthropic_key'] else 'openai' if cfg['openai_key'] else None
    return {'breakdown': text is not None, 'breakdown_provider': text,
            'breakdown_model': cfg['AI_TEXT_MODEL'] if text == 'claude' else cfg['AI_OPENAI_TEXT_MODEL'] if text else None,
            'variants': bool(cfg['openai_key']), 'image_model': cfg['AI_IMAGE_MODEL'],
            'sizes': list(SIZES), 'qualities': list(QUALITIES)}


def _scrub(text, cfg):
    for k in (cfg.get('anthropic_key'), cfg.get('openai_key')):
        if k:
            text = text.replace(k, '[key]')
    return re.sub(r'sk-[A-Za-z0-9_-]{8,}', '[key]', text)


def _post(url, headers, body, cfg, timeout=240):
    req = urllib.request.Request(url, data=body, headers=headers, method='POST')
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        raw = e.read().decode('utf-8', 'replace')
        try:
            msg = json.loads(raw).get('error', {})
            msg = msg.get('message') if isinstance(msg, dict) else str(msg)
        except ValueError:
            msg = raw[:300]
        raise AIError(_scrub(f'{e.code}: {msg}', cfg)) from None
    except (urllib.error.URLError, TimeoutError) as e:
        raise AIError(_scrub(f'Could not reach the API: {getattr(e, "reason", e)}', cfg)) from None


def _json_from(text):
    text = text.strip()
    fence = re.search(r'```(?:json)?\s*(.*?)```', text, re.S)
    if fence:
        text = fence.group(1)
    start, end = text.find('{'), text.rfind('}')
    if start < 0 or end <= start:
        raise AIError('The model did not return a breakdown. Try again.')
    return json.loads(text[start:end + 1])


# ---------- breakdown ----------
BREAKDOWN_SHAPE = '''{
  "verdict": "worked" | "mixed" | "did_not_work",
  "summary": "one sentence, plain words",
  "why": [{"point": "short reason", "evidence": "what in the image, copy or numbers shows it"}],
  "structure": {"hook": "", "layout": "", "product": "", "text_on_image": "", "offer": "", "proof": "", "cta": "", "look": ""},
  "keep": ["element to keep in new versions"],
  "test_next": ["one idea per line for a new version"],
  "watch_out": ["risk or weak spot"]
}'''


def breakdown_prompt(ad):
    """Text prompt shared by the local server and the shared page (same wording)."""
    return (
        "You are a senior performance creative strategist for Meta ads. Study this image ad from Gehna, "
        "an Indian fine jewellery brand, and explain why it performed the way it did.\n\n"
        f"Ad data (JSON):\n{json.dumps(ad, ensure_ascii=False)}\n\n"
        "Rules:\n- Use the image, the copy and the numbers. Compare the ad's ROAS, CPA and link CTR with the account "
        "averages given. If the numbers are weak, say so honestly and set verdict accordingly.\n"
        "- Plain, short sentences. No jargon. Use digits. No em dashes.\n"
        "- 3 to 5 items in why. 3 to 6 items in keep and test_next. 1 to 3 in watch_out.\n"
        "- structure: describe what is actually in the image. Use \"none\" when a part is missing.\n\n"
        f"Reply with only this JSON:\n{BREAKDOWN_SHAPE}"
    )


def breakdown(ad, image_bytes, media_type='image/jpeg', env_path=None):
    cfg = settings(env_path)
    prompt = breakdown_prompt(ad)
    b64 = base64.b64encode(image_bytes).decode() if image_bytes else None
    if cfg['anthropic_key']:
        content = ([{'type': 'image', 'source': {'type': 'base64', 'media_type': media_type, 'data': b64}}] if b64 else []) + [{'type': 'text', 'text': prompt}]
        body = json.dumps({'model': cfg['AI_TEXT_MODEL'], 'max_tokens': 2500, 'messages': [{'role': 'user', 'content': content}]}).encode()
        out = _post('https://api.anthropic.com/v1/messages', {'x-api-key': cfg['anthropic_key'], 'anthropic-version': '2023-06-01', 'content-type': 'application/json'}, body, cfg, timeout=180)
        text = ''.join(b.get('text', '') for b in out.get('content', []) if b.get('type') == 'text')
        model, provider = cfg['AI_TEXT_MODEL'], 'claude'
    elif cfg['openai_key']:
        content = [{'type': 'input_text', 'text': prompt}] + ([{'type': 'input_image', 'image_url': f'data:{media_type};base64,{b64}'}] if b64 else [])
        body = json.dumps({'model': cfg['AI_OPENAI_TEXT_MODEL'], 'input': [{'role': 'user', 'content': content}]}).encode()
        out = _post('https://api.openai.com/v1/responses', {'Authorization': f"Bearer {cfg['openai_key']}", 'Content-Type': 'application/json'}, body, cfg, timeout=180)
        text = out.get('output_text') or ''.join(c.get('text', '') for item in out.get('output', []) for c in item.get('content', []) or [] if c.get('type') == 'output_text')
        model, provider = cfg['AI_OPENAI_TEXT_MODEL'], 'openai'
    else:
        raise AIError('Add ANTHROPIC_API_KEY or OPENAI_API_KEY to .env, then restart the server.')
    data = clean_breakdown(_json_from(text))
    data.update({'model': model, 'provider': provider, 'date': time.strftime('%Y-%m-%d')})
    return data


def _txt(v, n):
    return re.sub(r'[\x00-\x1f\x7f]', ' ', str(v or '')).strip()[:n]


def clean_breakdown(d):
    """Validate a breakdown (from a model or from the page) into a safe, bounded shape."""
    if not isinstance(d, dict):
        raise AIError('Bad breakdown.')
    lst = lambda v, n, m: [_txt(x, m) for x in (v if isinstance(v, list) else [])[:n] if _txt(x, m)]
    why = []
    for w in (d.get('why') if isinstance(d.get('why'), list) else [])[:6]:
        if isinstance(w, dict) and _txt(w.get('point'), 200):
            why.append({'point': _txt(w.get('point'), 200), 'evidence': _txt(w.get('evidence'), 400)})
        elif isinstance(w, str) and w.strip():
            why.append({'point': _txt(w, 200), 'evidence': ''})
    st = d.get('structure') if isinstance(d.get('structure'), dict) else {}
    out = {
        'verdict': d.get('verdict') if d.get('verdict') in ('worked', 'mixed', 'did_not_work') else 'mixed',
        'summary': _txt(d.get('summary'), 400),
        'why': why,
        'structure': {k: _txt(st.get(k), 300) for k in ('hook', 'layout', 'product', 'text_on_image', 'offer', 'proof', 'cta', 'look')},
        'keep': lst(d.get('keep'), 8, 200),
        'test_next': lst(d.get('test_next'), 8, 240),
        'watch_out': lst(d.get('watch_out'), 4, 240),
    }
    for k in ('model', 'provider', 'date'):
        if d.get(k):
            out[k] = _txt(d.get(k), 60)
    if not out['summary'] and not out['why']:
        raise AIError('The breakdown came back empty. Try again.')
    return out


def load_breakdowns(path=None):
    try:
        data = json.loads(Path(path or BREAKDOWNS).read_text(encoding='utf-8'))
        return {k: clean_breakdown(v) for k, v in data.items() if SAFE_ID.match(k)}
    except (FileNotFoundError, ValueError, AIError):
        return {}


def save_breakdown(ad_id, data, path=None):
    if not SAFE_ID.match(str(ad_id)):
        raise AIError('Bad ad id.')
    path = Path(path or BREAKDOWNS)
    with _lock:
        all_ = load_breakdowns(path)
        all_[str(ad_id)] = clean_breakdown(data)
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix('.tmp')
        tmp.write_text(json.dumps(all_, ensure_ascii=False, indent=1), encoding='utf-8')
        tmp.replace(path)
    return all_[str(ad_id)]


# ---------- variants ----------
DIRECTIONS = [
    ('Same idea, new scene', 'Keep the same layout and message. Change the background, lighting and props so it feels like a fresh shoot.'),
    ('Product close-up', 'Make the jewellery the hero in a tight, sharp close-up on a clean premium background. Keep any headline short.'),
    ('Worn by a model', 'Show the same jewellery worn by an Indian woman in natural light, face partly visible, warm and aspirational.'),
    ('Proof-led', 'Lead with trust: a clean card layout that puts the proof from the original ad (reviews, certification, customers) next to the product.'),
]


def variant_prompt(ad, bd, direction):
    keep = '; '.join((bd or {}).get('keep', [])[:6]) or 'the product, the brand feel and the main message'
    head = ad.get('headline') or ''
    return (
        "Create a new square-safe Meta feed ad image for Gehna, an Indian fine jewellery brand, based on the attached ad.\n"
        "The jewellery must stay exactly the same design: same metal colour, stones, shape and proportions. Do not invent new pieces.\n"
        f"Keep what made the original work: {keep}.\n"
        f"Direction for this version: {direction}\n"
        "Text on the image: use only short text that already appears in the original ad"
        + (f" (for example the headline \"{head}\")" if head else "")
        + ". Do not invent prices, discounts, ratings, certifications or claims. Keep text crisp and spelled correctly, or leave text out.\n"
        "Leave some clear space near the edges. Photographic, premium, no watermarks, no logos other than what the original shows."
    )


def _multipart(fields, files):
    boundary = uuid.uuid4().hex
    parts = []
    for k, v in fields.items():
        parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode())
    for name, filename, ctype, data in files:
        parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"; filename="{filename}"\r\nContent-Type: {ctype}\r\n\r\n'.encode() + data + b'\r\n')
    parts.append(f'--{boundary}--\r\n'.encode())
    return b''.join(parts), f'multipart/form-data; boundary={boundary}'


def _edit(cfg, model, prompt, image_bytes, size, quality, fidelity=True):
    fields = {'model': model, 'prompt': prompt, 'size': size, 'quality': quality, 'n': '1', 'output_format': 'png'}
    if fidelity:
        fields['input_fidelity'] = 'high'
    body, ctype = _multipart(fields, [('image[]', 'reference.jpg', 'image/jpeg', image_bytes)])
    return _post('https://api.openai.com/v1/images/edits', {'Authorization': f"Bearer {cfg['openai_key']}", 'Content-Type': ctype}, body, cfg, timeout=300)


def make_variant(cfg, prompt, image_bytes, size, quality):
    """One image. Tries the configured model, then the fallback; drops input_fidelity if refused."""
    last = None
    for model in dict.fromkeys([cfg['AI_IMAGE_MODEL'], cfg['AI_IMAGE_FALLBACK']]):
        for fidelity in (True, False):
            try:
                out = _edit(cfg, model, prompt, image_bytes, size, quality, fidelity)
                item = (out.get('data') or [{}])[0]
                if not item.get('b64_json'):
                    raise AIError('The image API returned no image.')
                return base64.b64decode(item['b64_json']), model
            except AIError as e:
                last = e
                msg = str(e).lower()
                if fidelity and 'input_fidelity' in msg:
                    continue          # this model does not take input_fidelity: retry without it
                if 'model' in msg and ('not found' in msg or 'does not exist' in msg or 'access' in msg or 'invalid' in msg):
                    break             # try the fallback model
                raise
    raise last


def make_variants(ad_id, ad, image_bytes, bd, n=3, size='square', quality='medium', env_path=None, out_dir=None):
    cfg = settings(env_path)
    if not cfg['openai_key']:
        raise AIError('Add OPENAI_API_KEY to .env, then restart the server.')
    if not SAFE_ID.match(str(ad_id)):
        raise AIError('Bad ad id.')
    if not image_bytes:
        raise AIError('The ad image is not downloaded yet. Open the ad once so its image loads, then try again.')
    n = max(1, min(4, int(n)))
    size_px = SIZES.get(size, SIZES['square'])
    quality = quality if quality in QUALITIES else 'medium'
    folder = Path(out_dir or VARIANTS) / str(ad_id)
    folder.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime('%Y%m%d-%H%M%S')
    jobs = DIRECTIONS[:n]

    def run(i_dir):
        i, (label, direction) = i_dir
        try:
            png, model = make_variant(cfg, variant_prompt(ad, bd, direction), image_bytes, size_px, quality)
        except AIError as e:
            return {'label': label, 'error': str(e)}
        name = f'{stamp}_{i + 1}.png'
        (folder / name).write_bytes(png)
        meta = {'label': label, 'file': name, 'model': model, 'size': size_px, 'quality': quality, 'date': time.strftime('%Y-%m-%d %H:%M')}
        (folder / (name + '.json')).write_text(json.dumps(meta), encoding='utf-8')
        return meta

    with ThreadPoolExecutor(max_workers=min(n, 3)) as pool:
        results = list(pool.map(run, enumerate(jobs)))
    return results


def list_variants(ad_id, out_dir=None):
    if not SAFE_ID.match(str(ad_id)):
        return []
    folder = Path(out_dir or VARIANTS) / str(ad_id)
    out = []
    for meta in sorted(folder.glob('*.png.json'), reverse=True):
        try:
            m = json.loads(meta.read_text(encoding='utf-8'))
            if SAFE_FILE.match(m.get('file', '')) and (folder / m['file']).exists():
                out.append(m)
        except ValueError:
            continue
    return out[:24]


def variant_path(ad_id, name, out_dir=None):
    if not SAFE_ID.match(str(ad_id)) or not SAFE_FILE.match(name):
        return None
    p = Path(out_dir or VARIANTS) / str(ad_id) / name
    return p if p.is_file() else None
